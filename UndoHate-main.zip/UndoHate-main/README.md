UndoHate is a elegant website which takes text, image, video and audio input from the user.
It analyses the input and predicts the sentiment or emotion in the content.
It also finds the hate percentage in the input.
For text, image and video input, it hides or blurs the hate content.
For audio, the hate part is muted.
